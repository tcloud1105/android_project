package com.gohool.game.Util;

/**
 * Created by paulodichone on 4/28/17.
 */

public class Constants {
    public static final int WIDTH = 480;
    public static final int MOVEMENT = 2;
    public static final int HEIGHT = 800;
    public static final int GRAVITY = -15;
    public static final int FLUCTUATION = 120;
    public static final int TUBE_GAP = 100;
    public static final int LOWEST_OPENING = 130;
    public static final int TUBE_COUNT = 100;
    public static final int TUBE_SPACING = 145;
    public static final int TUBE_WIDTH = 52;
    public static final int GROUND_Y_OFFSET = -30;



}
