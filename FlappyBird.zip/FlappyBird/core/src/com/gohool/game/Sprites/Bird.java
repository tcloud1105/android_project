package com.gohool.game.Sprites;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

import org.w3c.dom.css.Rect;

import static com.gohool.game.Util.Constants.GRAVITY;
import static com.gohool.game.Util.Constants.MOVEMENT;


/**
 * Created by paulodichone on 4/28/17.
 */

public class Bird {
    private Vector2 position;
    private Vector2 velocity;
    private Texture bird;

    private Preferences scoreSaved;
    private Animation birdAnimation;

    //Sound
    private Sound flap;
    private Sound die;
    private Sound pointsSound;



    private Rectangle bounds; // for our bird's collision detection.


    public Bird(int x, int y) {
        position = new Vector2(x, y);
        velocity = new Vector2(0, 0);
        bird = new Texture("birdanimation.png");
        birdAnimation = new Animation(new TextureRegion(bird), 3, 0.5f);

        bounds = new Rectangle(x, y, bird.getWidth() / 3, bird.getHeight());

        scoreSaved = Gdx.app.getPreferences("flappy_b_score");


        flap = Gdx.audio.newSound(Gdx.files.internal("sfx_wing.ogg"));
        die = Gdx.audio.newSound(Gdx.files.internal("hit.mp3"));
        pointsSound = Gdx.audio.newSound(Gdx.files.internal("pointsound.mp3"));
    }

    public void saveScore(int myScore) {
        if (String.valueOf(scoreSaved.getInteger("score")) != null) {

            if (myScore > scoreSaved.getInteger("score")) {
                scoreSaved.putInteger("score", myScore);
                scoreSaved.flush(); // important!!


            }else {
                scoreSaved.putInteger("curr_score", myScore);
                scoreSaved.flush();
            }
        }
    }

    public int getCurrentScore() {
        Gdx.app.log("Curr score: ", String.valueOf(scoreSaved.getInteger("curr_score")));

        return scoreSaved.getInteger("curr_score");

    }
    public int getHighestScore() {
        Gdx.app.log("High score: ", String.valueOf(scoreSaved.getInteger("score")));
        return scoreSaved.getInteger("score");
    }

    public Vector2 getPosition() {
        return position;
    }


    public void playDieSound() {
        die.play();
    }
    public void playPointsound() {
        pointsSound.play();
    }


    public void update(float dt) {
        birdAnimation.update(dt);

        if (position.y > 0) {
            velocity.add(0, GRAVITY);
        }

        velocity.add(0, GRAVITY);
        velocity.scl(dt);
        position.add(MOVEMENT, velocity.y);

        if (position.y < 0) {
            position.y = 0;

        }
        velocity.scl(1/dt);

        bounds.setPosition(position.x, position.y);



    }
    public TextureRegion getTexture() {
        return  birdAnimation.getFrame();
    }

    public Rectangle getBounds() {
        return bounds;
    }

    public void jump() {
        flap.play(0.5f);
        velocity.y = 310;
    }

    public void dispose() {
        bird.dispose();
        flap.dispose();
        die.dispose();
        pointsSound.dispose();

    }
}
