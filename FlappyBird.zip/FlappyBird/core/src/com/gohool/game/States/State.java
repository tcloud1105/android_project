package com.gohool.game.States;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;

/**
 * Created by paulodichone on 4/28/17.
 */

public abstract class State { //state or screen

        protected OrthographicCamera camera;
        protected Vector2 vector2;
        protected GameStateManager gameStateManager;


    public State(GameStateManager gameStateManager) {
        this.gameStateManager = gameStateManager;

        camera = new OrthographicCamera();
        vector2 = new Vector2();
    }


    public abstract void handleInput();
    public abstract void update(float dt);
    public abstract void render(SpriteBatch spriteBatch);
    public abstract void dispose();
}
