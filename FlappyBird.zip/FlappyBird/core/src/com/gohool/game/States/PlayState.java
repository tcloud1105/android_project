package com.gohool.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.actions.RunnableAction;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Timer;
import com.gohool.game.Sprites.Bird;
import com.gohool.game.Sprites.Tube;
import com.gohool.game.Util.Constants;

import static com.gohool.game.Util.Constants.GROUND_Y_OFFSET;
import static com.gohool.game.Util.Constants.TUBE_COUNT;
import static com.gohool.game.Util.Constants.TUBE_SPACING;
import static com.gohool.game.Util.Constants.TUBE_WIDTH;

/**
 * Created by paulodichone on 4/28/17.
 */

public class PlayState extends State {

    private BitmapFont font;
    private Texture bg;
    private Bird bird;
   // private Tube tube;
    private Array<Tube> tubes;

    private Texture ground;
    private Vector2 groundPos1, groundPos2;
    private int pointsCounter = 0;


    public PlayState(GameStateManager gameStateManager) {
        super(gameStateManager);
        bird = new Bird(50, 300);
        camera.setToOrtho(false, Constants.WIDTH / 2, Constants.HEIGHT / 2);


        bg = new Texture("bg.png");
        ground = new Texture("ground.png");
      //  tube = new Tube(110);

        groundPos1 = new Vector2(camera.position.x - camera.viewportWidth / 2, GROUND_Y_OFFSET);
        groundPos2 = new Vector2(camera.position.x - camera.viewportWidth / 2 + ground.getWidth(), GROUND_Y_OFFSET );

        tubes = new Array<Tube>();

        for (int i = 1; i <= TUBE_COUNT; i++) {
            tubes.add(new Tube(i * (TUBE_SPACING + TUBE_WIDTH)));
        }




    }

    @Override
    public void handleInput() {

        if (Gdx.input.justTouched()) {
            bird.jump();
        }

    }

    @Override
    public void update(float dt) {
        handleInput();
        updateGround();
        bird.update(dt);

       // Gdx.app.log("Position", String.valueOf(bird.getPosition().y));

        //Follow our bird with the camera
        camera.position.x = bird.getPosition().x + 50;
        for (Tube tube : tubes) {
            //check if tube is off camera
            if (camera.position.x - ( camera.viewportWidth / 2) >
                    tube.getPosTopTube().x + tube.getTopTube().getWidth()) {
                tube.reposition(tube.getPosTopTube().x + ((Constants.TUBE_WIDTH +
                   Constants.TUBE_SPACING) * TUBE_COUNT));

            }

            //Check for collision
            if (tube.collides(bird.getBounds())) {
                //Bird died!
                bird.playDieSound();
                bird.saveScore(pointsCounter);
                tube.setCounter(pointsCounter);
                gameStateManager.set(new GameOverState(gameStateManager));

            }

            //Check for score collision
            if (tube.hasScored(bird.getBounds()) && tube.getCounter() == 0) {
                bird.playPointsound();
                pointsCounter += 2;
                tube.setCounter(pointsCounter);
                bird.saveScore(pointsCounter);
            }

        }
        hitGroud();
        camera.update();

    }

    public void hitGroud() {

        if (bird.getPosition().y <= ground.getHeight() + GROUND_Y_OFFSET) {
            bird.playDieSound();
            bird.saveScore(pointsCounter);

            Timer.schedule(new Timer.Task() {
                @Override
                public void run() {
                    gameStateManager.set(new GameOverState(gameStateManager));
                }
            }, 0.4f); //seconds not milliseconds

        }

    }

    @Override
    public void render(SpriteBatch spriteBatch) {

        spriteBatch.setProjectionMatrix(camera.combined);
        spriteBatch.begin();
        spriteBatch.draw(bg, camera.position.x - (camera.viewportWidth / 2),
                0);

        //draw bird to the screen
        spriteBatch.draw(bird.getTexture(), bird.getPosition().x, bird.getPosition().y);
        for (Tube tube : tubes) {
            spriteBatch.draw(tube.getTopTube(), tube.getPosTopTube().x, tube.getPosTopTube().y);
            spriteBatch.draw(tube.getBottomTube(),tube.getPosBotTube().x, tube.getPosBotTube().y);
        }

        //Draw ground
        spriteBatch.draw(ground, groundPos1.x, groundPos1.y );
        spriteBatch.draw(ground, groundPos2.x, groundPos2.y);


        //Draw Score to screen
        font = new BitmapFont(Gdx.files.internal("kenpixel.fnt"));
        font.setColor(Color.BROWN);
        font.getData().setScale(0.5f);

        font.draw(spriteBatch, "Score: " + pointsCounter,
                camera.position.x - (camera.viewportWidth / 2) + 100,
                camera.position.y + (camera.viewportWidth / 2) +  70);


        spriteBatch.end();


    }

    public void updateGround() {
        //check if the last ground is invisible
        if (camera.position.x - (camera.viewportWidth / 2) > groundPos1.x + ground.getWidth()) {
            groundPos1.add(ground.getWidth() * 2, 0);
        }
        if (camera.position.x - (camera.viewportWidth / 2) > groundPos2.x + ground.getWidth()) {
            groundPos2.add(ground.getWidth() * 2, 0);
        }
    }

    @Override
    public void dispose() {
        bg.dispose();
        ground.dispose();
        bird.dispose();

        for (Tube t : tubes) {
            t.dispose();
        }

    }
}
